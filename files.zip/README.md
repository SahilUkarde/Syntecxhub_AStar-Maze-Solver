# 🧩 A* Maze Solver

An interactive implementation of the **A\* (A-star) search algorithm** for finding the shortest path through a 2D grid maze. Built as part of an AI/algorithms internship project.

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue?logo=python)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Algorithm](https://img.shields.io/badge/Algorithm-A*%20Search-orange)](https://en.wikipedia.org/wiki/A*_search_algorithm)

---

## 📌 Features

- ✅ **A\* Search** with open/closed list and priority queue (min-heap)
- ✅ **3 Heuristics** — Manhattan, Euclidean, Chebyshev
- ✅ **Shortest path reconstruction** via parent backtracking
- ✅ **Unreachable goal handling** with clear error messages
- ✅ **Console visualization** (ASCII art, no dependencies)
- ✅ **Matplotlib visualization** — color-coded explored nodes & final path
- ✅ **Interactive web demo** (HTML/JS — open `demo/index.html`)
- ✅ **Diagonal movement** support (optional flag)
- ✅ **Stats** — nodes explored, path length, time elapsed

---

## 🚀 Quick Start

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/astar-maze-solver.git
cd astar-maze-solver
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the solver
```bash
# Console output (no dependencies needed)
python astar_solver.py

# With matplotlib visualization
python astar_solver.py --visualize

# Choose heuristic
python astar_solver.py --heuristic euclidean --visualize

# Open grid (no walls) — baseline test
python astar_solver.py --maze open --heuristic chebyshev --visualize

# Allow diagonal movement
python astar_solver.py --diag --visualize
```

---

## 🗂️ Project Structure

```
astar-maze-solver/
│
├── astar_solver.py       # Core A* implementation + CLI entry point
├── requirements.txt      # Python dependencies
├── .gitignore            # Files to exclude from Git
├── LICENSE               # MIT license
│
├── demo/
│   └── index.html        # Interactive browser demo (no server needed)
│
└── docs/
    └── algorithm.md      # Detailed algorithm explanation
```

---

## 🧠 How A\* Works

A\* finds the shortest path by evaluating each cell using:

```
f(n) = g(n) + h(n)
```

| Term | Meaning |
|------|---------|
| `g(n)` | Actual cost from **start** to node `n` |
| `h(n)` | **Heuristic** estimated cost from `n` to **goal** |
| `f(n)` | Total estimated cost — used to prioritize exploration |

A\* always expands the node with the **lowest f(n)** first, guaranteeing the shortest path when the heuristic is **admissible** (never overestimates).

### Heuristics Compared

| Heuristic | Formula | Best for |
|-----------|---------|----------|
| **Manhattan** | `\|Δrow\| + \|Δcol\|` | 4-directional grids (default) |
| **Euclidean** | `√(Δrow² + Δcol²)` | Any-angle movement |
| **Chebyshev** | `max(\|Δrow\|, \|Δcol\|)` | 8-directional (diagonal) grids |

---

## 🖥️ Console Output Example

```
[A*] Heuristic: Manhattan
[A*] Grid: 10×15  Start: (0,0)  Goal: (9,14)

=============================================
  A* Search — Results
=============================================
  Status        : Path found ✓
  Path length   : 28 steps
  Nodes explored: 74
  Heuristic     : manhattan
  Time elapsed  : 0.42 ms
=============================================

── Console Map ──
+──────────────────────────────┐
| S *  * ██  *  *  *  *  *  * |
|██ ██ * ██ ██  * ██ ██ ██  * |
|  ...                         |
+──────────────────────────────┘

Legend:  S=Start  G=Goal  *=Path  ×=Explored  ██=Wall
```

---

## 🌐 Interactive Web Demo

Open `demo/index.html` in any browser — no server or install needed.

**Features:**
- Draw/erase walls by clicking and dragging
- Move Start (S) and Goal (G) anywhere
- Step-by-step visualization with speed control
- Switch heuristics live and compare results
- g(n) cost shown on each explored cell

---

## 📊 Algorithm Complexity

| | Complexity |
|-|-----------|
| **Time** | O(b^d) where b = branching factor, d = depth |
| **Space** | O(b^d) — stores all generated nodes |
| **Optimality** | ✅ Guaranteed with admissible heuristic |
| **Completeness** | ✅ Always finds a path if one exists |

---

## 🔧 Use as a Module

```python
from astar_solver import AStarSolver, WALL, EMPTY

# Define your grid (0=empty, 1=wall)
grid = [
    [0, 0, 0, 1, 0],
    [1, 1, 0, 1, 0],
    [0, 0, 0, 0, 0],
    [0, 1, 1, 1, 0],
    [0, 0, 0, 0, 0],
]

solver = AStarSolver(
    grid=grid,
    start=(0, 0),
    goal=(4, 4),
    heuristic="manhattan",   # or "euclidean", "chebyshev"
    allow_diag=False,
)

path = solver.solve()

if path:
    print(f"Path: {path}")
    print(f"Length: {len(path) - 1} steps")
    print(f"Nodes explored: {solver.nodes_explored}")
else:
    print("Goal is unreachable!")
```

---

## 📚 References

- [A* Search Algorithm — Wikipedia](https://en.wikipedia.org/wiki/A*_search_algorithm)
- [Red Blob Games: Introduction to A*](https://www.redblobgames.com/pathfinding/a-star/introduction.html) ← highly recommended
- [Stanford CS221 — Search Algorithms](https://stanford.edu/~shervine/teaching/cs-221/cheatsheet-states-models)

---

## 🪪 License

[MIT](LICENSE) — free to use, modify, and distribute.

---

## 👤 Author

Made with ❤️ as an internship project.  
Feel free to ⭐ the repo if you found it useful!
